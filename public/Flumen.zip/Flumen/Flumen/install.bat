@echo off

:: Запрос прав администратора
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "CONFIG_X86=C:\Program Files (x86)\Common Files\Microsoft Shared\VSTO\10.0\VSTOInstaller.exe.config"
set "CONFIG_X64=C:\Program Files\Common Files\Microsoft Shared\VSTO\10.0\VSTOInstaller.exe.Config"

if exist "%CONFIG_X86%" (
    rename "%CONFIG_X86%" "VSTOInstaller.exe.config.bak"
)

if exist "%CONFIG_X64%" (
    rename "%CONFIG_X64%" "VSTOInstaller.exe.Config.bak"
)

start /wait "" "%~dp0setup.exe"

exit /b %ERRORLEVEL%